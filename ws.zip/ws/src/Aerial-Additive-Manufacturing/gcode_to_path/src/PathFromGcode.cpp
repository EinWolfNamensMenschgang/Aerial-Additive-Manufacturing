#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/path.hpp"
#include "gcode_to_path/msg/print_pose.hpp"
#include "gcode_to_path/msg/print_path.hpp"

#define OFFSET 0.03

struct Point {
    double x;
    double y;
    double z;

    Point(double x, double y, double z) : x(x), y(y), z(z) {}
};

class GCodePathPublisher : public rclcpp::Node {
public:
    GCodePathPublisher()
        : Node("gcode_path_publisher") {
        this->declare_parameter<std::string>("gcode_path", "");
        this->get_parameter("gcode_path", inputFilePath_);

        if (inputFilePath_.empty()) {
            RCLCPP_ERROR(this->get_logger(), "G-code path parameter is not set.");
            rclcpp::shutdown();
            return;
        }

        publisher_ = create_publisher<gcode_to_path::msg::PrintPath>("/print/path", 10);
        navPathPublisher_ = create_publisher<nav_msgs::msg::Path>("/nav/path", 10);
        timer_ = create_wall_timer(std::chrono::milliseconds(100), std::bind(&GCodePathPublisher::publishPath, this));
    }

private:
    void publishPath() {
        std::vector<Point> points;
        double currentZ = 0.0;

        std::ifstream inputFile(inputFilePath_);
        if (!inputFile.is_open()) {
            RCLCPP_ERROR(this->get_logger(), "Unable to open the specified file.");
            return;
        }

        gcode_to_path::msg::PrintPath printPathMsg;
        nav_msgs::msg::Path navPathMsg;
        printPathMsg.header.stamp = this->now();
        printPathMsg.header.frame_id = "map";
        navPathMsg.header.stamp = this->now();
        navPathMsg.header.frame_id = "map";

        std::string line;
        while (std::getline(inputFile, line)) {
            if (line.compare(0, 2, "G0") == 0 || line.compare(0, 2, "G1") == 0) {
                double x = 0.0, y = 0.0, z = currentZ;
                std::istringstream iss(line);
                std::string token;
                bool hasX = false, hasY = false;
                while (iss >> token) {
                    if (token[0] == 'X') {
                        x = std::stod(token.substr(1));
                        hasX = true;
                    } else if (token[0] == 'Y') {
                        y = std::stod(token.substr(1));
                        hasY = true;
                    } else if (token[0] == 'Z') {
                        z = std::stod(token.substr(1));
                        currentZ = z;
                    }
                }

                if (hasX && hasY) {
                    gcode_to_path::msg::PrintPose printPoseMsg;
                    printPoseMsg.pose.pose.position.x = x / 1000;
                    printPoseMsg.pose.pose.position.y = y / 1000;
                    printPoseMsg.pose.pose.position.z = OFFSET + z / 1000;

                    printPoseMsg.print = (line.compare(0, 2, "G0") == 0) ? false : true;

                    printPathMsg.path.push_back(printPoseMsg);

                    geometry_msgs::msg::PoseStamped poseStampedMsg;
                    poseStampedMsg.pose.position.x = x / 1000;
                    poseStampedMsg.pose.position.y = y / 1000;
                    poseStampedMsg.pose.position.z = OFFSET + z / 1000;

                    navPathMsg.poses.push_back(poseStampedMsg);
                }
            }
        }

        inputFile.close();

        publisher_->publish(printPathMsg);
        navPathPublisher_->publish(navPathMsg);
    }

    rclcpp::Publisher<gcode_to_path::msg::PrintPath>::SharedPtr publisher_;
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr navPathPublisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    std::string inputFilePath_;
};

int main(int argc, char* argv[]) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<GCodePathPublisher>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
